CC178 expanded manuscript, 19 September 2026

Compile main.tex with XeLaTeX (twice) or Tectonic. All referenced figures and
the original JPCS class/style files are included. No external bibliography
processor is required. The verified Tectonic build produces nine A4 pages.

This source package contains the manuscript and its referenced assets only.
It excludes participant videos, private configurations and build logs.
The expansion uses existing evidence; no new robot trials were conducted.
